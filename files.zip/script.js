/* =========================================================
   Student Productivity Hub - script.js
   Features: tasks, goals, progress tracker, timer, quotes
   Data is saved in localStorage so it survives page reloads.
   ========================================================= */

// ---------- Helpers ----------
const $ = (id) => document.getElementById(id);
const RING_LENGTH = 565.49; // circumference of the SVG ring (2 * PI * 90)

// Read a saved array from localStorage (returns [] if nothing is saved)
function load(key) {
  try { return JSON.parse(localStorage.getItem(key)) || []; }
  catch { return []; }
}
function save(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

// Build one list item (used by both tasks and goals)
function buildItem(item, onToggle, onDelete) {
  const li = document.createElement('li');
  if (item.done) li.classList.add('done');

  const box = document.createElement('input');
  box.type = 'checkbox';
  box.checked = item.done;
  box.setAttribute('aria-label', 'Mark as complete');
  box.addEventListener('change', onToggle);

  const text = document.createElement('span');
  text.className = 'text';
  text.textContent = item.text; // textContent keeps user input safe from HTML injection

  const del = document.createElement('button');
  del.className = 'del';
  del.innerHTML = '&times;';
  del.setAttribute('aria-label', 'Delete');
  del.addEventListener('click', onDelete);

  li.append(box, text, del);
  return li;
}

// ---------- Mobile navigation ----------
const navToggle = $('navToggle');
const navLinks = $('navLinks');
navToggle.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', open);
});
// Close the menu after choosing a link
navLinks.addEventListener('click', () => navLinks.classList.remove('open'));

// ---------- To-do list ----------
let tasks = load('hub-tasks');

function renderTasks() {
  const list = $('taskList');
  list.innerHTML = '';
  tasks.forEach((task, i) => {
    list.appendChild(buildItem(task,
      () => { task.done = !task.done; save('hub-tasks', tasks); renderTasks(); },
      () => { tasks.splice(i, 1); save('hub-tasks', tasks); renderTasks(); }
    ));
  });
  $('taskEmpty').style.display = tasks.length ? 'none' : 'block';
  updateProgress();
}

$('taskForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const value = $('taskInput').value.trim();
  if (!value) return;
  tasks.push({ text: value, done: false });
  save('hub-tasks', tasks);
  $('taskInput').value = '';
  renderTasks();
});

// ---------- Daily study goals ----------
let goals = load('hub-goals');

// Goals are "daily": if the saved date is not today, untick everything
const today = new Date().toDateString();
if (localStorage.getItem('hub-goals-date') !== today) {
  goals.forEach((g) => (g.done = false));
  save('hub-goals', goals);
  localStorage.setItem('hub-goals-date', today);
}

function renderGoals() {
  const list = $('goalList');
  list.innerHTML = '';
  goals.forEach((goal, i) => {
    list.appendChild(buildItem(goal,
      () => { goal.done = !goal.done; save('hub-goals', goals); renderGoals(); },
      () => { goals.splice(i, 1); save('hub-goals', goals); renderGoals(); }
    ));
  });
  $('goalEmpty').style.display = goals.length ? 'none' : 'block';
  updateProgress();
}

$('goalForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const value = $('goalInput').value.trim();
  if (!value) return;
  goals.push({ text: value, done: false });
  save('hub-goals', goals);
  $('goalInput').value = '';
  renderGoals();
});

// ---------- Progress tracker ----------
function updateProgress() {
  const total = tasks.length;
  const done = tasks.filter((t) => t.done).length;
  const goalsDone = goals.filter((g) => g.done).length;
  const percent = total ? Math.round((done / total) * 100) : 0;

  $('statTotal').textContent = total;
  $('statDone').textContent = done;
  $('statGoals').textContent = `${goalsDone}/${goals.length}`;
  $('barPercent').textContent = percent + '%';
  $('barFill').style.width = percent + '%';
  $('heroPercent').textContent = percent + '%';
  $('heroRing').style.strokeDashoffset = RING_LENGTH * (1 - percent / 100);
}

// ---------- Study timer ----------
let totalSeconds = 25 * 60;   // chosen session length
let remaining = totalSeconds; // seconds left
let endTime = 0;              // timestamp when the timer should finish
let intervalId = null;        // holds the running interval

function drawTimer() {
  const m = String(Math.floor(remaining / 60)).padStart(2, '0');
  const s = String(remaining % 60).padStart(2, '0');
  $('timerDisplay').textContent = `${m}:${s}`;
  // The ring empties as time runs out
  $('timerRing').style.strokeDashoffset = RING_LENGTH * (1 - remaining / totalSeconds);
  document.title = intervalId ? `${m}:${s} - Study Hub` : 'Student Productivity Hub';
}

function startTimer() {
  if (intervalId || remaining <= 0) return; // already running
  endTime = Date.now() + remaining * 1000;
  $('timerStatus').textContent = 'Focusing...';
  intervalId = setInterval(() => {
    // Using the clock (not a counter) keeps the timer accurate even in background tabs
    remaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1000));
    drawTimer();
    if (remaining === 0) {
      stopInterval();
      $('timerStatus').textContent = 'Session complete!';
      document.title = 'Session complete - Study Hub';
      alert('Great work! Your study session is complete. Take a short break.');
    }
  }, 250);
}

function stopInterval() { clearInterval(intervalId); intervalId = null; }

function pauseTimer() {
  if (!intervalId) return;
  stopInterval();
  $('timerStatus').textContent = 'Paused';
  drawTimer();
}

function resetTimer() {
  stopInterval();
  remaining = totalSeconds;
  $('timerStatus').textContent = 'Ready';
  drawTimer();
}

// Set a new session length (in minutes) and reset
function setDuration(minutes) {
  totalSeconds = minutes * 60;
  resetTimer();
}

$('startBtn').addEventListener('click', startTimer);
$('pauseBtn').addEventListener('click', pauseTimer);
$('resetBtn').addEventListener('click', resetTimer);

// Preset buttons (25 / 45 / 60 minutes)
document.querySelectorAll('.chip').forEach((chip) => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach((c) => c.classList.remove('active'));
    chip.classList.add('active');
    $('customMin').value = '';
    setDuration(Number(chip.dataset.min));
  });
});

// Custom minutes input (1 - 180)
$('customMin').addEventListener('input', (e) => {
  const mins = Math.min(180, Math.floor(Number(e.target.value)));
  if (mins >= 1) {
    document.querySelectorAll('.chip').forEach((c) => c.classList.remove('active'));
    setDuration(mins);
  }
});

// ---------- Motivational quotes ----------
const quotes = [
  { text: 'The secret of getting ahead is getting started.', author: 'Mark Twain' },
  { text: 'It always seems impossible until it is done.', author: 'Nelson Mandela' },
  { text: 'Success is the sum of small efforts, repeated day in and day out.', author: 'Robert Collier' },
  { text: 'Education is the passport to the future.', author: 'Malcolm X' },
  { text: 'The expert in anything was once a beginner.', author: 'Helen Hayes' },
  { text: 'Dream big, start small, but most of all, start.', author: 'Simon Sinek' },
  { text: 'You do not have to be great to start, but you have to start to be great.', author: 'Zig Ziglar' },
  { text: 'Believe you can and you are halfway there.', author: 'Theodore Roosevelt' }
];
let quoteIndex = Math.floor(Math.random() * quotes.length);

function showQuote() {
  const text = $('quoteText');
  text.classList.add('fade'); // fade out, swap text, fade back in
  setTimeout(() => {
    const q = quotes[quoteIndex];
    text.textContent = `\u201C${q.text}\u201D`;
    $('quoteAuthor').textContent = q.author;
    text.classList.remove('fade');
  }, 250);
}

$('quoteBtn').addEventListener('click', () => {
  quoteIndex = (quoteIndex + 1) % quotes.length; // always shows a different quote
  showQuote();
});

// ---------- Start-up ----------
$('year').textContent = new Date().getFullYear();
renderTasks();
renderGoals();
drawTimer();
showQuote();
